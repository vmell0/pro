
import os
import subprocess
import sys
import socket
import urllib.request
import json

cor_vermelha = "\033[91m"
cor_verde = "\033[92m"
cor_amarela = "\033[93m"
cor_azul = "\033[94m"
cor_reset = "\033[0m"

def adicionar_ao_cache(chave, valor):
    cache = carregar_cache()  
    cache[chave] = valor
    salvar_cache(cache)  

def remover_do_cache(chave):
    cache = carregar_cache()  
    if chave in cache:
        del cache[chave]
        salvar_cache(cache) 

def obter_do_cache(chave):
    cache = carregar_cache()  
    return cache.get(chave)

def carregar_cache():
    try:
        with open('/root/CheckUser/cache.json', 'r') as arquivo:
            return json.load(arquivo)
    except (FileNotFoundError, json.JSONDecodeError):
        return {} 
    
def salvar_cache(cache):
    with open('/root/CheckUser/cache.json', 'w') as arquivo:
        json.dump(cache, arquivo)


def get_public_ip():
    try:
        url = "https://ipinfo.io"
        response = urllib.request.urlopen(url)
        if response.status == 200:
            data = json.loads(response.read().decode("utf-8"))
            if 'ip' in data:
                return data['ip']
            else:
                print("ENDEREÇO IP PÚBLICO NÃO ENCONTRADO NA RESPOSTA.")
                return None
        else:
            print("FALHA NA SOLICITAÇÃO AO SERVIDOR.")
            return None
    except Exception as e:
        print("NÃO FOI POSSÍVEL OBTER O ENDEREÇO IP PÚBLICO: ", str(e))
        return None




def verificar_processo(nome_processo):
    try:
        resultado = subprocess.check_output(["ps", "aux"]).decode()
        linhas = resultado.split('\n')
        for linha in linhas:
            if nome_processo in linha and "python" in linha:
                return True
    except subprocess.CalledProcessError as e:
        print(f"ERRO AO VERIFICAR O PROCESSO: {e}")
    return False


nome_do_script = "/root/CheckUser/checkuser.py"




if __name__ == "__main__":
    while True:
        os.system('clear')


        if verificar_processo(nome_do_script):
            status = f'{cor_verde}ATIVO{cor_reset} - PORTA: {obter_do_cache("porta")}'
        else:
            status = f'{cor_vermelha}PARADO{cor_reset}'
       
        print(f"STATUS: {status}")

        print(f"")

        print(f"SELECIONE UMA OPÇÃO:")
        print(f"")
        print(f" 1 - INICIAR CHECKUSER")
        print(f" 2 - PARAR CHECKUSER")
        print(f" 3 - VERIFICAR LINKS")
        print(f" 0 - SAIR DO MENU")
        print(f"")
        option = input("DIGITE A OPÇÃO: ")

        if option == "1":

            print(f"PARA FUNCIONAR COM SECURITY, USE APENAS A PORTA: 5454 !")
            
            adicionar_ao_cache('porta', input("\nPORTA: "))

            os.system('clear')
            print(f'PORTA ESCOLHIDA: {obter_do_cache("porta")}')

            os.system(f'nohup python3 {nome_do_script} --port {obter_do_cache("porta")} & ')

            input(f"\nPRESSIONE A TECLA 'ENTER' PARA VOLTAR AO MENU\n\n")
        elif option == "2":
            if verificar_processo(nome_do_script):

                try:
                    subprocess.run(f'pkill -9 -f "/root/CheckUser/checkuser.py"', shell=True)

                        
                except subprocess.CalledProcessError:
                    print("ERRO AO EXECUTAR O COMANDO.")
                remover_do_cache("porta")
            else: 
                print("O CHECKUSER NÃO ESTÁ ATIVO.")
            


            input(f"PRESSIONE A TECLA 'ENTER' PARA VOLTAR AO MENU")
        elif option == "3":
            os.system('clear')
            if verificar_processo(nome_do_script):
                print("ABAIXO OS APPS, E OS LINKS PARA CADA UM: ")
                print("")
                ip = get_public_ip()
                porta = obter_do_cache("porta")
                print(f" DTUNNELMOD - http://adm.cvpn.com.br/api.php?url=http://{ip}:{porta}/dtmod  ")
                print(f"")
                print(f" GLTUNNELMOD - http://adm.cvpn.com.br/api.php?url=http://{ip}:{porta}/gl ")
                print(f"")
                print(f" ANYVPNMOD - http://adm.cvpn.com.br/api.php?url=http://{ip}:{porta}/anymod ")
                print(f"")
                print(f" CONECTA4G - http://adm.cvpn.com.br/api.php?url=http://{ip}:{porta}/checkUser ")
                print(f"")
                print(f" ATXTUNNEL - http://adm.cvpn.com.br/api.php?url=http://{ip}:{porta}/atx ")
                print("")

            else:
                print("\nINICIE O SERVIÇO PRIMEIRO\n")
            input(f"PRESSIONE A TECLA 'ENTER' PARA VOLTAR AO MENU")
                  

        elif option == "0":
            sys.exit(0)
        else:
            os.system('clear')
            print(f"SELECIONADO UMA OPÇÃO INVALIDA, TENTE NOVAMENTE !")
            input(f"PRESSIONE A TECLA 'ENTER' PARA VOLTAR AO MENU")
