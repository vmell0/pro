#!/bin/bash
python3 /root/CheckUser/checkuserMenu.py
